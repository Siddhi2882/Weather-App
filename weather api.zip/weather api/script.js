

"use strict";

// https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={API key}

const API_KEY = "e6986cc043db78c9a93b26ce224362b1";
const URL = "https://api.openweathermap.org/data/2.5/weather?units=metric&q=";

const searchBox = document.querySelector(".input-city");
const searchBtn = document.querySelector(".btn1");
const weatherIcon = document.querySelector(".weather-icon");

async function checkWeather(city) {
  const response = await fetch(URL + city + `&appid=${API_KEY}`);

  if (response.status == 404) {
    document.querySelector(".error").style.display = "block";
  } else {
    var data = await response.json();

    console.log(data);

    document.querySelector(".city").innerHTML = data.name;
    document.querySelector(".temp-heading").innerHTML =
      Math.round(data.main.temp) + "°C";
    document.querySelector(".speed").innerHTML =
      "Wind Speed : " + data.wind.speed + " km/h";
    document.querySelector(".humidity").innerHTML =
      "Humidity : " + data.main.humidity + "%";
    document.querySelector(".fahrenheit").innerHTML =
      "Fahrenheit : " + Math.round((data.main.temp * 9) / 5 + 32) + "°F";
    document.querySelector(".weater-info").innerHTML = data.weather[0].main;

    if (data.weather[0].main == "Clouds") {
      weatherIcon.src = "cloud.png";
    } else if (data.weather[0].main == "Clody") {
      weatherIcon.src = "images.jpeg";
    } else if (data.weather[0].main == "clear") {
      weatherIcon.src = "rainy.jpeg";
    } else if (data.weather[0].main == "Rainy") {
      weatherIcon.src = "drizzle.jpeg";
    } else if (data.weather[0].main == "drizzle") {
      weatherIcon.src = "mist.png";
    }
  }
}
searchBtn.addEventListener("click", () => {
  checkWeather(searchBox.value);
});

$(function () {
  var availableTags = [
    "mumbai",
    "paris",
    "delhi",
    "pune",
    "hyderabad",
    "kalyan",
    "agra",
    "chennai",
    "kolkata",
    "surat",
    "new york",
    "london",
    "tokyo",
    "bangkok",
    "dubai",
    "rome",
    "berlin",
    "moscow",
    "ulhasnagar",
    "manali",
    "miami",
    "lucknow",
  ];
  $("#tags").autocomplete({
    source: availableTags,
  });
});